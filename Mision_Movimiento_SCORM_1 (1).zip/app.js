const stations = [
  { title: 'El motor del movimiento', short: 'Funciones', number: '01', key: '7' },
  { title: 'Tres tejidos, tres misiones', short: 'Tipos de músculo', number: '02', key: '3' },
  { title: 'Mapa del cuerpo activo', short: 'Músculos', number: '03', key: '1' },
  { title: 'El equipo antagonista', short: 'Coordinación', number: '04', key: '9' },
  { title: 'Código de cuidado', short: 'Salud muscular', number: '05', key: '5' },
];

let currentStation = 0;
let completed = [];
let selectedAnswer = null;
let toastTimer;

const screens = document.querySelectorAll('.screen');
const stage = document.getElementById('station-stage');
const stationMap = document.getElementById('station-map');
const keySlots = document.getElementById('key-slots');
const progressBar = document.getElementById('progress-bar');
const progressLabel = document.getElementById('progress-label');
const progressPercent = document.getElementById('progress-percent');
const toast = document.getElementById('toast');

function showScreen(name) {
  screens.forEach(screen => screen.classList.toggle('active', screen.id === `screen-${name}`));
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
}

function renderKey() {
  keySlots.innerHTML = stations.map((station, index) => {
    const value = completed.includes(index) ? station.key : '·';
    return `<span class="key-slot ${completed.includes(index) ? 'filled' : ''}" aria-label="Fragmento ${index + 1}: ${value}">${value}</span>`;
  }).join('');
}

function renderMap() {
  stationMap.innerHTML = stations.map((station, index) => {
    const state = completed.includes(index) ? 'done' : index === currentStation ? 'current' : 'locked';
    return `<div class="station-node ${state}" aria-label="Estación ${index + 1}: ${station.short}">
      <span class="node-num">${station.number}</span><span class="node-name">${station.short}</span>
    </div>`;
  }).join('');
}

function updateProgress() {
  const percent = Math.round((completed.length / stations.length) * 100);
  progressLabel.textContent = completed.length === stations.length ? 'Misión completa' : `Estación ${currentStation + 1} de 5`;
  progressPercent.textContent = `${percent}%`;
  progressBar.style.width = `${percent}%`;
  renderKey();
  renderMap();
  window.scormBridge?.setProgress(currentStation + 1, percent);
}

function baseStation(station, body) {
  return `<article class="station-card">
    <span class="station-kicker">ESTACIÓN ${station.number} / ${station.short}</span>
    <h3>${station.title}</h3>
    ${body}
  </article>`;
}

function actionRow(hint, id = 'hint') {
  return `<div class="station-actions">
    <button class="button button-primary" data-action="check">Comprobar respuesta <span aria-hidden="true">↗</span></button>
    <button class="hint-button" data-action="hint" data-hint="${id}">Necesito una pista</button>
  </div>
  <div id="${id}" class="hint-box" role="note">${hint}</div>
  <div id="feedback" class="feedback" role="status" aria-live="polite"></div>`;
}

function renderStation() {
  selectedAnswer = null;
  updateProgress();
  const station = stations[currentStation];
  let body = '';
  if (currentStation === 0) body = renderStationOne();
  if (currentStation === 1) body = renderStationTwo();
  if (currentStation === 2) body = renderStationThree();
  if (currentStation === 3) body = renderStationFour();
  if (currentStation === 4) body = renderStationFive();
  stage.innerHTML = baseStation(station, body);
  attachStationEvents();
}

function renderStationOne() {
  return `<p class="station-intro">Descubre qué hacen los músculos cada vez que tu cuerpo se mueve. No necesitas memorizar todos sus nombres: primero identifica su función.</p>
    <span class="case-label">CASO DE OBSERVACIÓN</span><div class="case-box">Al levantar una mochila, los músculos del brazo cambian de longitud y producen fuerza. ¿Cuál es la función principal del sistema muscular?</div>
    <span class="question-label">Elige la respuesta que abre el primer seguro:</span>
    <div class="choice-grid">
      <button class="choice" data-choice="a"><strong>A</strong> Producir movimiento y mantener la postura</button>
      <button class="choice" data-choice="b"><strong>B</strong> Transportar oxígeno por la sangre</button>
      <button class="choice" data-choice="c"><strong>C</strong> Proteger todos los órganos como una armadura</button>
      <button class="choice" data-choice="d"><strong>D</strong> Fabricar los alimentos que necesita el cuerpo</button>
    </div>
    ${actionRow('Piensa en lo que ocurre cuando caminas, sonríes o mantienes la espalda erguida. Los músculos hacen más que mover huesos: también ayudan a sostener tu postura.', 'hint-1')}`;
}

function renderStationTwo() {
  return `<p class="station-intro">En el cuerpo existen tres tipos principales de tejido muscular. Cada uno tiene una ubicación y un nivel de control diferente.</p>
    <span class="case-label">PANEL DE CLASIFICACIÓN</span><div class="case-box">Relaciona cada ejemplo con el tipo de músculo correcto. Lee con cuidado: “voluntario” significa que puedes decidir cuándo usarlo.</div>
    <div class="select-grid">
      <div class="select-row"><label for="type-heart">Corazón</label><select class="field-select" id="type-heart"><option value="">Selecciona...</option><option value="skeletal">Esquelético</option><option value="smooth">Liso</option><option value="cardiac">Cardíaco</option></select></div>
      <div class="select-row"><label for="type-biceps">Bíceps</label><select class="field-select" id="type-biceps"><option value="">Selecciona...</option><option value="skeletal">Esquelético</option><option value="smooth">Liso</option><option value="cardiac">Cardíaco</option></select></div>
      <div class="select-row"><label for="type-intestine">Pared del intestino</label><select class="field-select" id="type-intestine"><option value="">Selecciona...</option><option value="skeletal">Esquelético</option><option value="smooth">Liso</option><option value="cardiac">Cardíaco</option></select></div>
    </div>
    ${actionRow('El corazón late sin que tengas que ordenárselo. Los músculos de los brazos sí dependen de una decisión consciente. El intestino mueve su contenido de manera automática.', 'hint-2')}`;
}

function renderStationThree() {
  return `<p class="station-intro">Los músculos principales reciben nombres que nos ayudan a ubicar y comprender sus movimientos. Completa el mapa corporal.</p>
    <span class="case-label">ATLAS DE MOVIMIENTO</span><div class="case-box">Selecciona el músculo o grupo muscular que corresponde a cada zona y función.</div>
    <div class="atlas-grid">
      <div class="atlas-item"><label for="muscle-arm">Parte anterior del brazo · flexiona el codo</label><select class="field-select" id="muscle-arm"><option value="">Selecciona...</option><option value="biceps">Bíceps</option><option value="triceps">Tríceps</option><option value="quad">Cuádriceps</option></select></div>
      <div class="atlas-item"><label for="muscle-thigh">Parte anterior del muslo · extiende la rodilla</label><select class="field-select" id="muscle-thigh"><option value="">Selecciona...</option><option value="calf">Gemelos</option><option value="quad">Cuádriceps</option><option value="glute">Glúteos</option></select></div>
      <div class="atlas-item"><label for="muscle-chest">Pecho · acerca el brazo al cuerpo</label><select class="field-select" id="muscle-chest"><option value="">Selecciona...</option><option value="pectoral">Pectoral</option><option value="abdominal">Abdominales</option><option value="deltoid">Deltoides</option></select></div>
      <div class="atlas-item"><label for="muscle-calf">Parte posterior de la pierna · ayuda a ponerse de puntas</label><select class="field-select" id="muscle-calf"><option value="">Selecciona...</option><option value="hamstring">Isquiotibiales</option><option value="calf">Gemelos</option><option value="quad">Cuádriceps</option></select></div>
    </div>
    ${actionRow('El bíceps está en la parte anterior del brazo. El cuádriceps ocupa la parte anterior del muslo. Los gemelos están detrás de la pierna y el pectoral cubre gran parte del pecho.', 'hint-3')}`;
}

function renderStationFour() {
  return `<p class="station-intro">Los músculos suelen trabajar en parejas. Mientras uno se contrae para producir un movimiento, el otro se relaja o controla el movimiento contrario.</p>
    <span class="case-label">SIMULADOR DE PAREJAS</span><div class="case-box">Completa las dos escenas del brazo. Recuerda: bíceps y tríceps son músculos antagonistas.</div>
    <div class="pair-grid">
      <div class="pair-card"><h4>Escena A · flexionar el codo</h4><div class="select-row"><label for="flex-main">Músculo principal</label><select class="field-select" id="flex-main"><option value="">Selecciona...</option><option value="biceps-contract">Bíceps se contrae</option><option value="triceps-contract">Tríceps se contrae</option></select></div><div class="select-row"><label for="flex-other">Músculo opuesto</label><select class="field-select" id="flex-other"><option value="">Selecciona...</option><option value="triceps-relax">Tríceps se relaja</option><option value="biceps-relax">Bíceps se relaja</option></select></div></div>
      <div class="pair-card"><h4>Escena B · extender el codo</h4><div class="select-row"><label for="extend-main">Músculo principal</label><select class="field-select" id="extend-main"><option value="">Selecciona...</option><option value="biceps-contract">Bíceps se contrae</option><option value="triceps-contract">Tríceps se contrae</option></select></div><div class="select-row"><label for="extend-other">Músculo opuesto</label><select class="field-select" id="extend-other"><option value="">Selecciona...</option><option value="triceps-relax">Tríceps se relaja</option><option value="biceps-relax">Bíceps se relaja</option></select></div></div>
    </div>
    ${actionRow('Para flexionar el codo, acerca el antebrazo al brazo: el bíceps se contrae. Para extenderlo, ocurre lo contrario: el tríceps se contrae y el bíceps se relaja.', 'hint-4')}`;
}

function renderStationFive() {
  return `<p class="station-intro">Cuidar los músculos también es parte de la misión. Clasifica estas prácticas según ayuden o no a mantener un sistema muscular saludable.</p>
    <span class="case-label">PROTOCOLO DE CUIDADO</span><div class="case-box">Elige “Saludable” o “Necesita cambiar” para cada hábito. No se trata de ser perfecto: se trata de reconocer buenas decisiones.</div>
    <div class="habit-grid">
      <div class="habit-row"><span>Calentar antes de hacer ejercicio</span><select class="field-select" id="habit-warm"><option value="">Selecciona...</option><option value="healthy">Saludable</option><option value="change">Necesita cambiar</option></select></div>
      <div class="habit-row"><span>Dormir y permitir la recuperación</span><select class="field-select" id="habit-sleep"><option value="">Selecciona...</option><option value="healthy">Saludable</option><option value="change">Necesita cambiar</option></select></div>
      <div class="habit-row"><span>Hacer ejercicio intenso sin hidratarse</span><select class="field-select" id="habit-water"><option value="">Selecciona...</option><option value="healthy">Saludable</option><option value="change">Necesita cambiar</option></select></div>
      <div class="habit-row"><span>Mantener una postura cómoda y activa</span><select class="field-select" id="habit-posture"><option value="">Selecciona...</option><option value="healthy">Saludable</option><option value="change">Necesita cambiar</option></select></div>
      <div class="habit-row"><span>Ignorar un dolor fuerte al entrenar</span><select class="field-select" id="habit-pain"><option value="">Selecciona...</option><option value="healthy">Saludable</option><option value="change">Necesita cambiar</option></select></div>
      <div class="habit-row"><span>Consumir agua y alimentos variados</span><select class="field-select" id="habit-food"><option value="">Selecciona...</option><option value="healthy">Saludable</option><option value="change">Necesita cambiar</option></select></div>
    </div>
    ${actionRow('Calentar, hidratarse, alimentarse de forma variada, dormir y respetar el dolor son decisiones de cuidado. Si aparece un dolor fuerte, hay que detenerse y pedir orientación.', 'hint-5')}`;
}

function attachStationEvents() {
  document.querySelectorAll('.choice').forEach(choice => choice.addEventListener('click', () => {
    document.querySelectorAll('.choice').forEach(item => item.classList.remove('selected'));
    choice.classList.add('selected');
    selectedAnswer = choice.dataset.choice;
  }));
  document.querySelectorAll('[data-action="hint"]').forEach(button => button.addEventListener('click', () => {
    const hint = document.getElementById(button.dataset.hint);
    hint.classList.toggle('visible');
    button.textContent = hint.classList.contains('visible') ? 'Ocultar pista' : 'Necesito una pista';
  }));
  document.querySelector('[data-action="check"]').addEventListener('click', checkStation);
}

function getValues(ids) {
  return ids.map(id => document.getElementById(id)?.value || '');
}

function checkStation() {
  let correct = false;
  if (currentStation === 0) correct = selectedAnswer === 'a';
  if (currentStation === 1) correct = JSON.stringify(getValues(['type-heart', 'type-biceps', 'type-intestine'])) === JSON.stringify(['cardiac', 'skeletal', 'smooth']);
  if (currentStation === 2) correct = JSON.stringify(getValues(['muscle-arm', 'muscle-thigh', 'muscle-chest', 'muscle-calf'])) === JSON.stringify(['biceps', 'quad', 'pectoral', 'calf']);
  if (currentStation === 3) correct = JSON.stringify(getValues(['flex-main', 'flex-other', 'extend-main', 'extend-other'])) === JSON.stringify(['biceps-contract', 'triceps-relax', 'triceps-contract', 'biceps-relax']);
  if (currentStation === 4) correct = JSON.stringify(getValues(['habit-warm', 'habit-sleep', 'habit-water', 'habit-posture', 'habit-pain', 'habit-food'])) === JSON.stringify(['healthy', 'healthy', 'change', 'healthy', 'change', 'healthy']);

  const feedback = document.getElementById('feedback');
  feedback.classList.add('visible');
  if (!correct) {
    feedback.className = 'feedback error visible';
    feedback.innerHTML = '<strong>Aún no.</strong> Revisa tus elecciones y vuelve a intentarlo. La pista puede ayudarte a encontrar la relación clave.';
    showToast('El seguro sigue cerrado. ¡Puedes intentarlo otra vez!');
    return;
  }

  if (!completed.includes(currentStation)) completed.push(currentStation);
  feedback.className = 'feedback visible';
  const explanations = [
    'Los músculos producen movimiento, ayudan a mantener la postura y también protegen y sostienen estructuras del cuerpo.',
    'El músculo cardíaco trabaja de forma involuntaria; el esquelético se relaciona con el movimiento voluntario y el liso actúa en órganos internos.',
    'Ubicar un músculo permite comprender mejor qué movimiento realiza y cómo participa en acciones cotidianas.',
    'Los músculos antagonistas se coordinan: uno puede contraerse mientras el otro se relaja para producir movimientos opuestos.',
    'Calentar, hidratarse, descansar, alimentarse bien y escuchar el dolor ayudan a prevenir lesiones y cuidar el sistema muscular.',
  ];
  feedback.innerHTML = `<strong>¡Seguro abierto!</strong> ${explanations[currentStation]} <span class="fragment-note">Fragmento recuperado: <b>${stations[currentStation].key}</b></span>`;
  showToast(`Fragmento ${stations[currentStation].key} recuperado`);
  document.querySelector('[data-action="check"]').disabled = true;
  document.querySelector('[data-action="check"]').style.opacity = '.55';
  updateProgress();

  if (completed.length === stations.length) {
    setTimeout(showSuccess, 850);
  } else {
    document.querySelector('[data-action="check"]').insertAdjacentHTML('afterend', '<button class="button button-ghost" data-action="next">Siguiente estación <span aria-hidden="true">→</span></button>');
    document.querySelector('[data-action="next"]').addEventListener('click', () => { currentStation += 1; renderStation(); });
  }
}

const simulatorModes = {
  flex: {
    title: 'Flexionar el codo',
    description: 'El antebrazo se acerca al brazo. El bíceps se acorta y produce el movimiento.',
    biceps: 'se contrae',
    triceps: 'se relaja',
    angle: 45,
  },
  extend: {
    title: 'Extender el codo',
    description: 'El antebrazo se aleja del brazo. El tríceps se contrae y el bíceps se relaja.',
    biceps: 'se relaja',
    triceps: 'se contrae',
    angle: 0,
  },
  hold: {
    title: 'Mantener la posición',
    description: 'El brazo permanece estable. Ambos músculos pueden trabajar con tensión para sostener la postura.',
    biceps: 'trabaja con tensión',
    triceps: 'trabaja con tensión',
    angle: 90,
  },
};

function updateSimulator(mode, customAngle = null) {
  const setting = simulatorModes[mode];
  const angle = customAngle === null ? setting.angle : Number(customAngle);
  document.getElementById('motion-title').textContent = setting.title;
  document.getElementById('motion-description').textContent = setting.description;
  document.getElementById('biceps-status').textContent = customAngle === null ? setting.biceps : angle > 18 ? 'se acorta' : 'se relaja';
  document.getElementById('triceps-status').textContent = customAngle === null ? setting.triceps : angle > 18 ? 'se relaja' : 'se contrae';
  document.getElementById('angle-value').textContent = `${angle}°`;
  document.getElementById('angle-slider').value = angle;
  document.getElementById('sim-forearm').style.transform = `translateY(-50%) rotate(${angle}deg)`;
  document.querySelectorAll('.motion-button').forEach(button => button.classList.toggle('active', button.dataset.motion === mode));
  const dots = document.querySelectorAll('.status-dot');
  dots[0]?.classList.toggle('active', (customAngle === null ? setting.biceps : angle > 18) !== 'se relaja');
  dots[0]?.classList.toggle('resting', (customAngle === null ? setting.biceps : angle > 18) === 'se relaja');
  dots[1]?.classList.toggle('active', (customAngle === null ? setting.triceps : angle <= 18) !== 'se relaja');
  dots[1]?.classList.toggle('resting', (customAngle === null ? setting.triceps : angle <= 18) === 'se relaja');
}

function openSimulator() {
  showScreen('simulator');
  updateSimulator('flex');
}

const atlasData = {
  biceps: { number: '01', name: 'Bíceps', location: 'Parte anterior del brazo.', function: 'Ayuda a flexionar el codo y acercar el antebrazo al brazo.', example: 'Levantar una mochila, saludar o acercar un vaso a la boca.', vocab: 'Flexión' },
  pectoral: { number: '02', name: 'Pectoral', location: 'Parte superior y anterior del pecho.', function: 'Ayuda a acercar el brazo al cuerpo y a realizar movimientos de empuje.', example: 'Empujar una puerta o abrazar a otra persona.', vocab: 'Empuje' },
  abdominal: { number: '03', name: 'Abdominales', location: 'Zona anterior del tronco.', function: 'Estabilizan el tronco y colaboran al flexionar el cuerpo.', example: 'Sentarse, levantarse o mantener el equilibrio.', vocab: 'Estabilidad' },
  quad: { number: '04', name: 'Cuádriceps', location: 'Parte anterior del muslo.', function: 'Extiende la rodilla y participa en caminar, correr y saltar.', example: 'Subir escaleras o levantarse de una silla.', vocab: 'Extensión' },
  calf: { number: '05', name: 'Gemelos', location: 'Parte posterior de la pierna.', function: 'Ayudan a extender el pie y a elevar el talón.', example: 'Ponerse de puntas o dar el impulso para saltar.', vocab: 'Impulso' },
};

function updateAtlas(zone) {
  const data = atlasData[zone];
  if (!data) return;
  document.getElementById('atlas-number').textContent = data.number;
  document.getElementById('atlas-name').textContent = data.name;
  document.getElementById('atlas-location').textContent = data.location;
  document.getElementById('atlas-function').textContent = data.function;
  document.getElementById('atlas-example').textContent = data.example;
  document.getElementById('atlas-vocab').textContent = data.vocab;
  document.querySelectorAll('.body-zone').forEach(button => button.classList.toggle('active', button.dataset.zone === zone));
}

function openAtlas() {
  showScreen('atlas');
  updateAtlas('biceps');
}

function openVideo() {
  showScreen('video');
}

document.querySelectorAll('[data-action="simulator"]').forEach(button => button.addEventListener('click', openSimulator));
document.querySelectorAll('[data-action="atlas"]').forEach(button => button.addEventListener('click', openAtlas));
document.querySelectorAll('[data-action="video"]').forEach(button => button.addEventListener('click', openVideo));
document.querySelectorAll('[data-action="back-home"]').forEach(button => button.addEventListener('click', () => showScreen('home')));
document.querySelectorAll('.motion-button').forEach(button => button.addEventListener('click', () => updateSimulator(button.dataset.motion)));
document.getElementById('angle-slider').addEventListener('input', event => updateSimulator('hold', event.target.value));
document.querySelectorAll('.body-zone').forEach(button => button.addEventListener('click', () => updateAtlas(button.dataset.zone)));

function showSuccess() {
  document.getElementById('final-code-value').textContent = stations.map(station => station.key).join('');
  window.scormBridge?.complete(100);
  showScreen('success');
}

function startMission() {
  currentStation = 0;
  completed = [];
  window.scormBridge?.init();
  showScreen('mission');
  renderStation();
}

document.querySelectorAll('[data-action="start"]').forEach(button => button.addEventListener('click', startMission));
document.querySelector('[data-action="briefing"]').addEventListener('click', () => showScreen('briefing'));
document.querySelector('[data-action="restart"]').addEventListener('click', () => showScreen('home'));
renderKey();
