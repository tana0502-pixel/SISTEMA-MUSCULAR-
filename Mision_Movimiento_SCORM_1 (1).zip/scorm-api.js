/* Puente SCORM 1.2: funciona en un LMS y no interfiere con el Preview local. */
(function () {
  let api = null;
  let initialized = false;

  function findAPI(win) {
    let attempts = 0;
    while (win && attempts < 8) {
      try {
        if (win.API) return win.API;
        if (win.parent && win.parent !== win) win = win.parent;
        else break;
      } catch (_) { break; }
      attempts += 1;
    }
    try { if (window.opener && window.opener.API) return window.opener.API; } catch (_) {}
    return null;
  }

  function setValue(element, value) {
    if (!api || !initialized) return;
    try { api.LMSSetValue(element, String(value)); } catch (_) {}
  }

  function commit() {
    if (!api || !initialized) return;
    try { api.LMSCommit(''); } catch (_) {}
  }

  window.scormBridge = {
    init() {
      api = findAPI(window);
      if (!api) return false;
      try {
        initialized = api.LMSInitialize('') === 'true';
        if (initialized) {
          const status = api.LMSGetValue('cmi.core.lesson_status');
          if (!status || status === 'not attempted') setValue('cmi.core.lesson_status', 'incomplete');
          commit();
        }
      } catch (_) { initialized = false; }
      return initialized;
    },
    setProgress(station, percent) {
      setValue('cmi.core.lesson_location', `estacion-${station}`);
      setValue('cmi.core.score.raw', percent);
      setValue('cmi.core.score.min', 0);
      setValue('cmi.core.score.max', 100);
      setValue('cmi.suspend_data', JSON.stringify({ station, percent }));
      commit();
    },
    complete(score) {
      setValue('cmi.core.lesson_status', 'completed');
      setValue('cmi.core.score.raw', score);
      setValue('cmi.core.score.min', 0);
      setValue('cmi.core.score.max', 100);
      setValue('cmi.core.exit', '');
      commit();
    },
    finish() {
      if (!api || !initialized) return;
      try { api.LMSFinish(''); } catch (_) {}
      initialized = false;
    }
  };

  window.addEventListener('load', () => window.scormBridge.init());
  window.addEventListener('beforeunload', () => window.scormBridge.finish());
})();
